﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace fstCopy_Proj5.Models
{
    public class CirclesViewModel
    {
        public int ActiveCircleId { get; set; }
        public List<int> Circles { get; set; }
    }
}